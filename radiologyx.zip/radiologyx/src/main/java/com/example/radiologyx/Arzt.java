package com.example.radiologyx;

public class Arzt {


}
