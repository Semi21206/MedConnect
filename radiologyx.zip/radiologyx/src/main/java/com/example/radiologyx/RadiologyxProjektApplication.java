package com.example.radiologyx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RadiologyxProjektApplication {

	public static void main(String[] args) {
		SpringApplication.run(RadiologyxProjektApplication.class, args);
	}

}
